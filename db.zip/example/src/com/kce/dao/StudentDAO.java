package com.kce.dao;

import com.kce.model.Student;

public interface StudentDAO {
 Student doStudent(Student StudentBean);


}
