package com.kce.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kce.model.Student;

@Repository("studentDAO")
public class StudentDAOImpl implements StudentDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	@Transactional
	
	
	@Override
	public Student doStudent(Student StudentBean)
	{
		sessionFactory.getCurrentSession().save(StudentBean);
		return StudentBean;		
		
	}

}
