package com.kce.service;
import com.kce.model.Student;
public interface StudentDetail {
	Student doStudent(Student StudentBean) ;
}
