package com.kce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kce.model.Student;
import com.kce.dao.StudentDAO;

@Service("StudentDetail")
public class StudentDetailImple implements StudentDetail {
	
	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	@Transactional
	public Student doStudent(Student StudentBean)
	{
		Student a=(Student)studentDAO.doStudent(StudentBean);
		return a;
	}

}
